import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import '../../styles/Header.css';
import logo from '../../assets/Struqton Structures.png';

const Header = () => {
  const [isMobile, setIsMobile] = useState(window.innerWidth <= 480);
  
  // Handle window resize and detect mobile
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth <= 480);
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);
    
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  return (
    <header className="header">
      <Link to="/" className="logo">
        <img src={logo} alt="Struqton Structural Logo" className="logo-image" />
      </Link>

      {/* Only show navigation on desktop */}
      {!isMobile && (
        <nav className="nav">
          <ul>
            <li><Link to="/">HOME</Link></li>
            <li><Link to="/about">ABOUT US</Link></li>
            <li><Link to="/projects">PROJECTS</Link></li>
            <li><Link to="/blog">BLOG</Link></li>
            <li><Link to="/contacts">CONTACTS</Link></li>
          </ul>
        </nav>
      )}
    </header>
  );
};

export default Header; 