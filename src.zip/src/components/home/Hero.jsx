import { Link } from 'react-router-dom';
import '../../styles/Hero.css';

const Hero = () => {
  return (
    <section className="hero">
      <div className="hero-content">
        <div className="project-number">
          <span className="number">01</span>
          <span className="of">/ 04</span>
        </div>
        <div className="hero-tags">
          <span className="tag">PREV</span>
          <span className="tag">NEXT</span>
        </div>
        <h1 className="hero-title">STRUQTON STRUCTURAL</h1>
        <p className="hero-text">
          Struqton Structural provides premium construction services in Zimbabwe. 
          With innovative design and sustainable features, our projects represent the pinnacle of 
          modern construction excellence.
        </p>
        <Link to="/about" className="hero-button">
          LEARN MORE
        </Link>
      </div>
    </section>
  );
};

export default Hero; 