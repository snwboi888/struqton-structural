import { Link } from 'react-router-dom';
import '../../styles/AboutSection.css';

const AboutSection = () => {
  return (
    <section className="about-section-home">
      <div className="container">
        <h2 className="section-title">ABOUT US</h2>
        <p className="about-intro-home">
          Struqton Structural is a team of dedicated construction professionals creating buildings that inspire, transform, and endure.
        </p>
        
        <div className="values-grid-home">
          <div className="value-item-home">
            <h3>Innovation</h3>
            <p>We constantly push the boundaries of architectural design, seeking new solutions and approaches to create unique and meaningful spaces.</p>
          </div>
          <div className="value-item-home">
            <h3>Sustainability</h3>
            <p>We are committed to environmentally responsible design practices that minimize ecological impact and promote energy efficiency.</p>
          </div>
          <div className="value-item-home">
            <h3>Collaboration</h3>
            <p>We believe in the power of teamwork and partnership, working closely with clients, engineers, and contractors to achieve exceptional results.</p>
          </div>
          <div className="value-item-home">
            <h3>Excellence</h3>
            <p>We strive for excellence in every aspect of our work, from conceptual design to the smallest construction detail.</p>
          </div>
        </div>
        
        <div className="about-cta">
          <Link to="/about" className="about-link">Learn More About Us</Link>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
