import React from 'react';
import '../../styles/ProjectHighlight.css';
import slowgradImage from '../../assets/Telegram Desktop/SLOWGRAD SANDTON.png';

const ProjectHighlight = () => {
  // Project statistics
  const stats = [
    { value: '18,500', label: 'Square Meters' },
    { value: '24', label: 'Months Duration' },
    { value: '120+', label: 'Workers Involved' },
    { value: '5', label: 'Awards Won' }
  ];

  return (
    <div className="project-highlight-container">
      <div className="section-header">
        <h2>FEATURED PROJECT</h2>
        <div className="header-underline"></div>
      </div>
      
      <div className="highlight-content">
        <div className="highlight-image-container">
          <img src={slowgradImage} alt="Slowgrad Sandton Project" className="highlight-image" />
          <div className="highlight-overlay">
            <span className="highlight-label">FEATURED</span>
          </div>
        </div>
        
        <div className="highlight-details">
          <h3 className="highlight-title">SLOWGRAD SANDTON</h3>
          <p className="highlight-description">
            An iconic structure that defines the Sandton skyline, this mixed-use development 
            combines modern design principles with sustainable construction practices. 
            The project represents our commitment to excellence in large-scale commercial developments.
          </p>
          
          <div className="highlight-stats">
            {stats.map((stat, index) => (
              <div key={index} className="stat-item">
                <span className="stat-value">{stat.value}</span>
                <span className="stat-label">{stat.label}</span>
              </div>
            ))}
          </div>
          
          <div className="highlight-features">
            <h4>PROJECT FEATURES</h4>
            <ul>
              <li>Sustainable design with LEED Gold certification</li>
              <li>Double-glazed façade for energy efficiency</li>
              <li>Integrated smart building management systems</li>
              <li>Underground parking for 500+ vehicles</li>
              <li>Rooftop garden and recreational spaces</li>
            </ul>
          </div>
          
          <button className="highlight-button">VIEW FULL PROJECT</button>
        </div>
      </div>
    </div>
  );
};

export default ProjectHighlight; 