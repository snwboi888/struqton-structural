import '../styles/AboutPage.css';

const AboutPage = () => {
  return (
    <div className="about-page">
      <div className="about-header">
        <h1>ABOUT GO.ARCH</h1>
        <p className="about-intro">
          We are a team of dedicated architects creating spaces that inspire, transform, and endure.
        </p>
      </div>

      <div className="about-content">
        <div className="about-section">
          <h2>Our Philosophy</h2>
          <p>
            At GO.ARCH, we believe that architecture should not only be aesthetically pleasing but also functional, sustainable, and reflective of the culture and environment in which it exists. We are committed to creating spaces that enrich people's lives, foster community, and stand the test of time.
          </p>
        </div>

        <div className="about-section">
          <h2>Our Approach</h2>
          <p>
            We take a collaborative approach to every project, working closely with clients to understand their vision, needs, and constraints. We believe that the best designs emerge from a deep understanding of the context and purpose of a space, combined with innovative thinking and meticulous attention to detail.
          </p>
        </div>
      
        <div className="about-section">
          <h2>Our Values</h2>
          <div className="values-grid">
            <div className="value-item">
              <h3>Innovation</h3>
              <p>We constantly push the boundaries of architectural design, seeking new solutions and approaches to create unique and meaningful spaces.</p>
            </div>
            <div className="value-item">
              <h3>Sustainability</h3>
              <p>We are committed to environmentally responsible design practices that minimize ecological impact and promote energy efficiency.</p>
            </div>
            <div className="value-item">
              <h3>Collaboration</h3>
              <p>We believe in the power of teamwork and partnership, working closely with clients, engineers, and contractors to achieve exceptional results.</p>
            </div>
            <div className="value-item">
              <h3>Excellence</h3>
              <p>We strive for excellence in every aspect of our work, from conceptual design to the smallest construction detail.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AboutPage; 