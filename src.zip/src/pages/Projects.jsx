import ProjectsGrid from '../components/projects/ProjectsGrid';
import '../styles/ProjectsPage.css';

const ProjectsPage = () => {
  return (
    <div className="projects-page">
      <div className="projects-header">
        <h1>OUR PROJECTS</h1>
        <p className="projects-intro">
          Discover our portfolio of innovative architectural projects spanning different scales and typologies.
        </p>
      </div>
      
      <div className="projects-filter">
        <button className="filter-button active">All</button>
        <button className="filter-button">Commercial</button>
        <button className="filter-button">Residential</button>
        <button className="filter-button">Cultural</button>
        <button className="filter-button">Healthcare</button>
      </div>
      
      <ProjectsGrid />
    </div>
  );
};

export default ProjectsPage; 