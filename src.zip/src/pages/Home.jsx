import Hero from '../components/home/Hero';
import Services from '../components/home/Services';
import AboutSection from '../components/home/AboutSection';
import ContactSection from '../components/home/ContactSection';
import StoryGallery from '../components/home/StoryGallery';
import PhotoShowcase from '../components/home/PhotoShowcase';
import ProjectHighlight from '../components/home/ProjectHighlight';
import ClientsSection from '../components/home/ClientsSection';
import '../styles/HomeSections.css';

const Home = () => {
  return (
    <>
      {/* Hero Section - Main banner */}
      <Hero />
      
      {/* Featured Project Highlight */}
      <ProjectHighlight />
      
      {/* Our Company Info Sections */}
      <div className="company-info-container">
        <div className="section-header">
          <h2>ABOUT STRUQTON STRUCTURAL</h2>
          <div className="header-underline"></div>
        </div>
        
        <div className="info-sections-grid">
          {/* Our Philosophy Section */}
          <section className="philosophy info-card">
            <div className="info-icon">
              <i className="philosophy-icon"></i>
            </div>
            <h3>Our Philosophy</h3>
            <p>Our mission at Struqton Structural is to design, build and deliver innovatively structured and competitively priced projects.</p>
          </section>

          {/* Our Vision Section */}
          <section className="vision info-card">
            <div className="info-icon">
              <i className="vision-icon"></i>
            </div>
            <h3>Our Vision</h3>
            <p>To become a preferred world-class Construction Company.</p>
          </section>

          {/* Our Core Values Section */}
          <section className="core-values info-card">
            <div className="info-icon">
              <i className="values-icon"></i>
            </div>
            <h3>Our Core Values</h3>
            <ul>
              <li>Professionalism</li>
              <li>Efficiency</li>
              <li>Timeliness</li>
              <li>Transparency</li>
              <li>Integrity</li>
            </ul>
          </section>
        </div>
      </div>
      
      {/* Our Services Section */}
      <div className="services-container">
        <div className="section-header">
          <h2>OUR SERVICES</h2>
          <div className="header-underline"></div>
        </div>
        
        <section className="services-content">
          <div className="services-intro">
            <p>We provide RESIDENTIAL, INDUSTRIAL, AGRICULTURAL & COMMERCIAL construction services as a main contractor or sub-contractor.</p>
            <h3>Building Services include:</h3>
          </div>
          
          <div className="services-grid">
            <div className="service-item">
              <div className="service-icon building-icon"></div>
              <h4>Building Construction</h4>
            </div>
            <div className="service-item">
              <div className="service-icon engineering-icon"></div>
              <h4>Civil And Structural Engineering Works</h4>
            </div>
            <div className="service-item">
              <div className="service-icon concrete-icon"></div>
              <h4>Concrete works</h4>
            </div>
            <div className="service-item">
              <div className="service-icon brick-icon"></div>
              <h4>Bricklaying</h4>
            </div>
            <div className="service-item">
              <div className="service-icon carpentry-icon"></div>
              <h4>Carpentry & Joinery</h4>
            </div>
            <div className="service-item">
              <div className="service-icon electrical-icon"></div>
              <h4>Electrical Installation</h4>
            </div>
            <div className="service-item">
              <div className="service-icon maintenance-icon"></div>
              <h4>Operations and Maintenance Services</h4>
            </div>
          </div>
        </section>
      </div>
      
      {/* Project Story Gallery - Visual storytelling */}
      <StoryGallery />
      
      {/* Photo Showcase - Visual portfolio */}
      <PhotoShowcase />
      
      {/* Our Clients Section */}
      <ClientsSection />
      
      {/* About Company Section - Our values */}
      <AboutSection />
      
      {/* Contact Section - Get in touch */}
      <ContactSection />
    </>
  );
};

export default Home; 